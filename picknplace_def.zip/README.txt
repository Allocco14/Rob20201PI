Pick & Place (para MATLAB)

- picknplace_def.m -

Instrucciones de uso:

1. Instale la fuente tipográfica incluida (Prototype.ttf) con MATLAB cerrado.
2. Asegúrese de contar con el Toolbox de Peter Corke instalado y activado en MATLAB.
3. Traslade al path de MATLAB los archivos de imágenes incluidos.
4. Traslade al path de MATLAB el archivo principal picknplace_def.m.
5. Abra MATLAB y corra el archivo principal.